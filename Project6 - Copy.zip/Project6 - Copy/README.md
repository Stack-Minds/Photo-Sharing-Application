# Scrum Team
## Product Owner:
Pallavi Deshmukh 
## Scrum Master:
Venkata Avinash Mallampati
## Developers:
- Pallavi Deshmukh
- Venkata Avinash Mallampati
- Praharsha Srikar Kadambari
- Adarsh Kodumuru
- Sai Pallavi Vangala
- Supraj Bejugam
